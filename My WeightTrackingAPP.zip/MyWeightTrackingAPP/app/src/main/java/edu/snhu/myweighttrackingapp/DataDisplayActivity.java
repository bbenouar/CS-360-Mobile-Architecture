package edu.snhu.myweighttrackingapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView weightRecyclerView;
    private WeightDataAdapter weightDataAdapter;
    private List<WeightData> weightDataList;
    private Spinner unitSpinner;
    private EditText weightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize Spinner
        unitSpinner = findViewById(R.id.unit_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.weight_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);

        // Initialize EditText
        weightInput = findViewById(R.id.weight_input);

        // Initialize RecyclerView and other UI components
        weightRecyclerView = findViewById(R.id.weight_recycler_view);
        weightDataList = new ArrayList<>();
        weightDataAdapter = new WeightDataAdapter(weightDataList);

        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightRecyclerView.setAdapter(weightDataAdapter);

        // Handle add and clear button clicks (Implement the logic in separate methods)
        findViewById(R.id.add_button).setOnClickListener(view -> addWeightData());
        findViewById(R.id.clear_button).setOnClickListener(view -> clearWeightData());
    }

    private void addWeightData() {
        String weight = weightInput.getText().toString();
        String unit = unitSpinner.getSelectedItem().toString();
        if (!weight.isEmpty()) {
            weightDataList.add(new WeightData(weight, unit));
            weightDataAdapter.notifyDataSetChanged();
        }
    }

    private void clearWeightData() {
        weightDataList.clear();
        weightDataAdapter.notifyDataSetChanged();
    }
}


