package edu.snhu.myweighttrackingapp;

public class WeightData {
    private String weight;
    private String unit;

    public WeightData(String weight, String unit) {
        this.weight = weight;
        this.unit = unit;
    }

    public String getWeight() {
        return weight;
    }

    public String getUnit() {
        return unit;
    }
}
