package edu.snhu.myweighttrackingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private List<DataItem> dataList;

    public DataAdapter(List<DataItem> dataList) {
        this.dataList = dataList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        DataItem dataItem = dataList.get(position);
        holder.weightTextView.setText(dataItem.getWeight());
        holder.unitTextView.setText(dataItem.getUnit());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView weightTextView;
        public TextView unitTextView;

        public ViewHolder(View view) {
            super(view);
            weightTextView = view.findViewById(R.id.weight_text_view);
            unitTextView = view.findViewById(R.id.unit_text_view);
        }
    }
}

