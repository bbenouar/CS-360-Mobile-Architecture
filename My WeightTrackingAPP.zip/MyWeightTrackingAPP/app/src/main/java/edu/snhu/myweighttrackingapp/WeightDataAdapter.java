package edu.snhu.myweighttrackingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightDataAdapter extends RecyclerView.Adapter<WeightDataAdapter.ViewHolder> {

    private List<WeightData> weightDataList;

    public WeightDataAdapter(List<WeightData> weightDataList) {
        this.weightDataList = weightDataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightData weightData = weightDataList.get(position);
        holder.weightTextView.setText(weightData.getWeight());
        holder.unitTextView.setText(weightData.getUnit());
    }

    @Override
    public int getItemCount() {
        return weightDataList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView;
        TextView unitTextView;

        ViewHolder(View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weight_text_view);
            unitTextView = itemView.findViewById(R.id.unit_text_view);
        }
    }
}

